var searchData=
[
  ['max',['max',['../struct_s_d_l_visual_test___s_u_t_int_range.html#ae1e1dde676c120fa6d10f3bb2c14059e',1,'SDLVisualTest_SUTIntRange']]],
  ['min',['min',['../struct_s_d_l_visual_test___s_u_t_int_range.html#a3e202b201e6255d975cd6d3aff1f5a4d',1,'SDLVisualTest_SUTIntRange']]]
];
